import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_squared_error


# LOAD DATA

df = pd.read_csv(
 r"C:\C++ vs code\.vscode\Sample - Superstore.csv",
 encoding="latin1"
)


# KPI VALUES

total_sales = df["Sales"].sum()
total_profit = df["Profit"].sum()
avg_sales = df["Sales"].mean()
total_orders = df["Order ID"].nunique()

print("Total Sales:", total_sales)
print("Total Profit:", total_profit)
print("Average Sales:", avg_sales)
print("Total Orders:", total_orders)


# OUTLIER REMOVE

Q1 = df["Sales"].quantile(0.25)
Q3 = df["Sales"].quantile(0.75)
IQR = Q3 - Q1

df_clean = df[
(df["Sales"] >= Q1 - 1.5 * IQR) &
(df["Sales"] <= Q3 + 1.5 * IQR)
]


# LINEAR REGRESSION

X = df_clean[["Sales"]]
y = df_clean["Profit"]

X_train,X_test,y_train,y_test = train_test_split(
X,y,test_size=0.2,random_state=42
)

model = LinearRegression()
model.fit(X_train,y_train)

y_pred = model.predict(X_test)

print("R2 Score:", r2_score(y_test,y_pred))
print("MSE:", mean_squared_error(y_test,y_pred))
#Histogram
plt.figure()
sns.histplot(df["Sales"], kde=True)
plt.title("Sales Distribution")
plt.show()

#Category Sales
plt.figure()
sns.barplot(x="Category", y="Sales", data=df)
plt.xticks(rotation=20)
plt.title("Category Sales")
plt.show()

#Region Sales
plt.figure()
sns.barplot(x="Region", y="Sales", data=df)
plt.xticks(rotation=30)
plt.title("Region Sales")
plt.show()

#Outlier Boxplot
plt.figure()
sns.boxplot(x=df["Sales"])
plt.title("Outlier Detection")
plt.show()

# Linear Regression
plt.figure()
sns.regplot(x="Sales", y="Profit", data=df_clean)
plt.title("Linear Regression")
plt.show()

#Scatter Plot
plt.figure()
sns.scatterplot(x="Sales", y="Profit", hue="Category", data=df)
plt.title("Sales vs Profit")
plt.show()

#Heatmap
plt.figure()
sns.heatmap(
df[["Sales","Profit","Quantity","Discount"]].corr(),
annot=True,
cmap="coolwarm"
)
plt.title("Correlation Heatmap")
plt.show()

#Profit by Segment
plt.figure()
sns.barplot(x="Segment", y="Profit", data=df)
plt.xticks(rotation=20)
plt.title("Segment Profit")
plt.show()

#Pie Chart
plt.figure()
df["Category"].value_counts().plot.pie(autopct='%1.1f%%')
plt.title("Category Share")
plt.show()

#KDE Plot
plt.figure()
sns.kdeplot(df["Profit"], fill=True)
plt.title("Profit Density")
plt.show()
